<?php

class FrontSearch extends CWidget
{

	public function run() {
		$this->render('front_search');	
	}
}
?>