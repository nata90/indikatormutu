<?php

class FrontSearchPage extends CWidget
{

	public function run() {

		$this->render('front_search_page');	
	}
}
?>