<div id="frame_title">
<h3 align="left">Menu</h3>
</div>
<ul id="" class="list_menu">
	<li><a class="dir" href="<?php echo Yii::app()->createUrl('site/login');?>">Login</a>
		
	</li>
	<li><a class="dir" href="#">MASTER</a>
		<ul>
			<li><a href="index.php?link=add_user">ADD USER</a></li>
			<li><a href="index.php?link=private">LIST USER</a></li>
			<li><a href="?link=191">EDIT ICD</a></li>
			<li><a href="?link=19">LIST ICD</a></li>
			<li><a href="index.php?link=jdoc2">ADD JADWAL</a></li>
			<li><a href="index.php?link=jdoc3">LIST JADWAL</a></li>
		</ul>
	</li>
</ul>