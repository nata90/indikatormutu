<div class="quick-menu">
	<?php echo Faq::model()->makeMenu();?>
	<?php /* <ul id="1" class="first">
		<li><a href="<?php echo Yii::app()->controller->createUrl('aboutecc');?>" title="Tentang ECC UGM">Tentang ECC UGM</a></li>
		<li><a id="second-3" class="child" off_address="" href="javascript:void(0);" title="Keanggotaan">Keanggotaan</a></li>
		<li><a id="second-2" class="child" off_address="" href="javascript:void(0);" title="Training">Training</a></li>
	</ul>
	<ul id="second-3" class="second">
		<li><a href="<?php echo Yii::app()->controller->createUrl('jobseeker');?>" title="Keanggotaan1">Keanggotaan1</a></li>
		<li><a id="third-1" class="child" off_address="" href="javascript:void(0);" title="Keanggotaan2">Keanggotaan2</a></li>
		<li><a id="third-1-2" class="child" off_address="" href="javascript:void(0);" title="Keanggotaan3">Keanggotaan3</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('student');?>" title="Training">Keanggotaan4</a></li>
		<li><a id="back" class="back" off_address="" href="javascript:void(0);" title="Back">Back</a></li>
	</ul>
	<ul id="second-2" class="second">
		<li><a href="<?php echo Yii::app()->controller->createUrl('jobseeker');?>" title="ECC Self Diagnostic Tools">ECC Self Diagnostic Tools3</a></li>
		<li><a id="third-2-1" class="child" off_address="" href="javascript:void(0);" title="Konseling Karir">Konseling Karir3</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('student');?>" title="Training">Training3</a></li>
		<li><a id="back" class="back" off_address="" href="javascript:void(0);" title="Back">Back</a></li>
	</ul>
	<ul id="third-1" class="third">
		<li><a href="<?php echo Yii::app()->controller->createUrl('jobseeker');?>" title="ECC Self Diagnostic Tools">ECC Self Diagnostic Tools4</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('employer');?>" title="Konseling Karir">Konseling Karir3</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('student');?>" title="Training">Training3</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('employer');?>" title="Konseling Karir">Konseling Karir34</a></li>
		<li><a name="second-1" id="back" class="back" off_address="" href="javascript:void(0);" title="Back">Back</a></li>
	</ul>
	<ul id="third-1-2" class="third">
		<li><a href="<?php echo Yii::app()->controller->createUrl('jobseeker');?>" title="ECC Self Diagnostic Tools">ECC Self Diagnostic Tools12345678</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('employer');?>" title="Konseling Karir">Konseling Karir3</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('student');?>" title="Training">Training3</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('employer');?>" title="Konseling Karir">Konseling Karir3</a></li>
		<li><a name="second-1" id="back" class="back" off_address="" href="javascript:void(0);" title="Back">Back</a></li>
	</ul>
	<ul id="third-2-1" class="third">
		<li><a href="<?php echo Yii::app()->controller->createUrl('jobseeker');?>" title="ECC Self Diagnostic Tools">Hariaz</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('employer');?>" title="Konseling Karir">Konseling Karir3</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('student');?>" title="Training">Training3</a></li>
		<li><a href="<?php echo Yii::app()->controller->createUrl('employer');?>" title="Konseling Karir">Konseling Karir3</a></li>
		<li><a name="second-2" id="back" class="back" off_address="" href="javascript:void(0);" title="Back">Back</a></li>
	</ul> */ ?>
</div>