<?php //begin Contact Widget ?>
<div class="widget-contact">
	<a class="main-link" href="javascript:void(0);" off_address=""><span></span>Hubungi Kami!</a>
	<div class="box">
		<div class="boxes">
			<ul class="menu clearfix">
				<li><a name="message" class="active" href="javascript:void(0);" off_address="">Kirim Pesan</a></li>
				<li><a name="chat" href="javascript:void(0);" off_address="">Chat Online</a></li>
			</ul>
			<fieldset class="message content-box">
				<div>
					<input type="text" id="" name="" maxlength="" class="span-11" placeholder="Nama">
				</div>
				<div>
					<input type="text" id="" name="" maxlength="" class="span-11" placeholder="Email">
				</div>
				<div>
					<input type="text" id="" name="" maxlength="" class="span-11" placeholder="Subject">
				</div>
				<div>
					<input type="text" id="" name="" maxlength="" class="span-11" placeholder="Website">
				</div>
				<div>
					<textarea class="span-11 small" placeholder="Pesan Anda"></textarea>
				</div>
				<div class="button-box center">
					<input type="submit" value="Submit" name="" class="submit">
				</div>
			</fieldset>
			<div class="chat content-box">
				<ul class="clearfix">
					<li><a href="ymsgr:sendIM?hariaz_freak" off_address=""><img src="<?php echo Yii::app()->request->baseUrl;?>/public/main/yahoo_online.png" alt="yahoo_online.png"></a></li>
					<li><a href="ymsgr:sendIM?hariaz_freak" off_address=""><img src="<?php echo Yii::app()->request->baseUrl;?>/public/main/yahoo_offlie.png" alt="yahoo_offline.png"></a></li>
					<li><a href="ymsgr:sendIM?hariaz_freak" off_address=""><img src="<?php echo Yii::app()->request->baseUrl;?>/public/main/yahoo_online.png" alt="yahoo_online.png"></a></li>
					<li><a href="ymsgr:sendIM?hariaz_freak" off_address=""><img src="<?php echo Yii::app()->request->baseUrl;?>/public/main/yahoo_offlie.png" alt="yahoo_offline.png"></a></li>
				</ul>
			</div>
		</div>
	</div>
</div>
<?php //end Contact Widget ?>
