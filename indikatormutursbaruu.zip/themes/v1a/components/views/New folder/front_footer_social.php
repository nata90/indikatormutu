<?php //begin.Social Feeds ?>
<div class="social-feed">
	<div class="container clearfix">
		<ul>
			<li><a href="<?php echo Yii::app()->createUrl('site/about');?>" title="tentang ECC"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/ecc_ugm.png" alt="tentang ECC">tentang ECC</a></li>
			<li><a off_address="" href="<?php echo Yii::app()->createUrl('blog');?>" target="_blank" title="Blog"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/wordpress.png" alt="Blog">Blog</a></li>
			<li><a href="<?php echo Yii::app()->createUrl('site/socialmedia');?>" title="Social Media"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/social_media.png" alt="Social Media">Social Media</a></li>
			<li><a off_address="" href="http://careernews.web.id/gallery/archive/category/photo" target="_blank" title="Gallery"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/gallery.png" alt="Gallery">Gallery</a></li>
			<?php /*<li><a href="<?php echo Yii::app()->createUrl('site/mobileapps');?>" title="Mobile Apps"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/ecc_apps.png" alt="Mobile Apps">Mobile Apps</a></li>*/ ?>
                        <li><a target="_blank" href="http://ecc.ft.ugm.ac.id/apps/index" title="Mobile Apps"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/ecc_apps.png" alt="Mobile Apps">Mobile Apps</a></li>
			<li><a off_address="" href="<?php echo Yii::app()->createUrl('site/support');?>" title="Contact"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/ecc_support.png" alt="Contact">Contact</a></li>
			<?php /* <li><a href="<?php echo Yii::app()->createUrl('site/rss');?>" title="RSS"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/rss.png" alt="RSS">RSS</a></li>
			<li><a off_address=""  href="<?php echo Yii::app()->createUrl('faq');?>" title="FAQ"><img src="<?php echo Yii::app()->theme->baseUrl;?>/images/social/faq.png" alt="faq">faq</a></li> */?>
		</ul>
	</div>
</div>
<?php //end.Social Feeds ?>
