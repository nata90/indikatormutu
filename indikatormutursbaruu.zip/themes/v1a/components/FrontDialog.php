<?php

class FrontDialog extends CWidget
{

	public function run() { 
		// $this->render('front_top_menu', array(
			// 'topMenu'=>$topMenu,
		// )); 
		$this->render('front_dialog'); 
	}
}
?>