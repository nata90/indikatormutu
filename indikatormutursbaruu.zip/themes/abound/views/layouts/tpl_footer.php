	<footer>
        <div class="subnav navbar navbar-fixed-bottom">
            <div class="navbar-inner">
                <div class="container">
                    <!-- Designed by <a href="http://www.webapplicationthemes.com" target="_new">webapplicationthemes.com</a>. All Rights Reserved.<br /> -->
					Powered by <a href="http://www.rsupsoeradji.id" title="RS Ramah Lansia" target="_new">Instalasi SIRS - RSST @ 2019</a>
                </div>
            </div>
        </div>      
	</footer>

