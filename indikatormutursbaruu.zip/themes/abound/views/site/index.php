<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
$baseUrl = Yii::app()->theme->baseUrl; 
?>

<h1>Selamat Datang di <b><?php echo CHtml::encode(Yii::app()->name); ?></b></h1>

<p>Ini adalah aplikasi Komite Mutu untuk penliaian Ikdikator Mutu tiap satuan Kerja.</p>

