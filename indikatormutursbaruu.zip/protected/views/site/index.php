<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name;
?>

<h1>Selamat Datang di Aplikasi Indikator Mutu</h1>

<p>Aplikasi digunakan sebagai media untuk melaporkan capaian Indikator Mutu setiap satuan kerja.</p>
