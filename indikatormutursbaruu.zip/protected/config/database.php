<?php

// This is the database connection configuration.
return array(
	//'connectionString' => 'sqlite:'.dirname(__FILE__).'/../data/testdrive.db',
	// uncomment the following lines to use a MySQL database
	
	/*'connectionString' => 'mysql:host=localhost;dbname=indikatormutursbaru',
	'emulatePrepare' => true,
	'username' => 'sinergis',
	'password' => '1qazxsw2',
	'charset' => 'utf8',
	'class'   => 'CDbConnection' */

	'connectionString' => 'mysql:host=localhost;dbname=indiikator_mutu',
	'emulatePrepare' => true,
	'username' => 'root',
	'password' => '',
	'charset' => 'utf8',
	'class'   => 'CDbConnection'
	
);